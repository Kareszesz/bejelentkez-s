f_nevek = []
jelszavak = []


with open("felhasználó.txt", "r", encoding="utf-8") as f:
    lines = f.readlines()

    for line in lines:
        parts = line.strip().split(";")
        if len(parts) == 2: 
            f_nevek.append(parts[0])
            jelszavak.append(parts[1])

def menu():
    while True:
        print("\n----- Főoldal -----")
        melyik = input("""1.Bejelentkezés\n2.Regisztráció\n3.Kilépés\n""")
        
        if melyik == "1":
            bejelentkezes()
        elif melyik == "2":
            regisztarcio()
        elif melyik == "3":
            break

def bejelentkezes():
    print("----- Bejelentkezés -----")
    
    while True:
        nev = input("Írd be a felhasználó nevedet: ")
        if nev == "quit":
            break

        if nev in f_nevek:
            index = f_nevek.index(nev)
            jelszo = input("Írd be a jelszavadat: ")
            if jelszavak[index] == jelszo:
                print("Sikeres bejelentkezés!")
                break
            else:
                print("Hibás jelszó!")
        else:
            print("Nem létezik ilyen felhasználónév! \nHa még nincsen fiókod regisztrálj!")

def regisztarcio():
    while True:
        print("----- Regisztráció -----")

        felh_nev = input("Írd be a felhasználó nevedet: ")
        if felh_nev == "quit":
            break

        if felh_nev in f_nevek:
            print("Ez a felhasználónév már foglalt!")
        else:
            jelszo = input("Írd be a jelszavadat: ")
            jelszo2 = input("Erősítsd meg a jelszavadat: ")

            if jelszo != jelszo2:
                print("Nem egyezik meg a két jelszó!")
            else:
                with open("felhasználó.txt", "a", encoding="utf-8") as f:
                    f.write(felh_nev + ";" + jelszo + "\n")
                
                f_nevek.append(felh_nev)
                jelszavak.append(jelszo)
                print("Sikeres regisztráció!")
                break

menu()
